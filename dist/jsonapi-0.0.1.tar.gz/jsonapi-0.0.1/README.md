# jsonapi

A custom JSON API to handle complex numbers.

## Installation

```bash
pip install git+https://github.com/nuoxu0728/jsonapi.git